#include "fusion_thermal_birth.h"
#include <vector>
#include <cstdio>
#include <cmath>
#include <chrono>
int main(){const double kev=1.602176634e-16,mev=1.602176634e-13;int n=128;std::vector<double> e(n+1),b(7*n),old(7*n);for(int i=0;i<=n;++i)e[i]=25*mev*i/n;
fusion_thermal_birth_options_v1 o{2.5*mev,40,.09184*mev,.001*mev,.76,0,.051,1,1,0,0,13,0,16,12,8,8};
std::puts("channel,angle_order,seconds,rate_error,debit_error,number_L1_previous,energy_L1_previous");
for(int ch:{3,0}){fusion_thermal_birth_v1 prev{};for(int order:{4,8,16,32}){
fusion_thermal_birth_v1 r{};auto t=std::chrono::steady_clock::now();int s=fusion_c_thermal_pair_birth_grid(ch,(ch?20:100)*kev,(ch?40:200)*kev,order,&o,n,e.data(),b.data(),&r);if(s){std::fprintf(stderr,"ch%d order%d status%d\n",ch,order,s);return s;}
long double dN=0,N=0,dE=0,E=0;for(int id=0;id<7;++id){dN+=std::abs(r.below_number_m3_s[id]-prev.below_number_m3_s[id])+std::abs(r.above_number_m3_s[id]-prev.above_number_m3_s[id]);N+=r.below_number_m3_s[id]+r.above_number_m3_s[id];dE+=std::abs(r.below_energy_J_m3_s[id]-prev.below_energy_J_m3_s[id])+std::abs(r.above_energy_J_m3_s[id]-prev.above_energy_J_m3_s[id]);E+=r.below_energy_J_m3_s[id]+r.above_energy_J_m3_s[id];for(int j=0;j<n;++j){int k=id*n+j;long double c=(e[j]+e[j+1])/2;dN+=std::abs(b[k]-old[k]);N+=b[k];dE+=c*std::abs(b[k]-old[k]);E+=c*b[k];}}
std::printf("%d,%d,%.9g,%.9g,%.9g,%.9Lg,%.9Lg\n",ch,order,std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count(),r.relative_rate_discrepancy,r.relative_reactant_energy_discrepancy,order==4?0:dN/N,order==4?0:dE/E);std::fflush(stdout);old=b;prev=r;
}}
}
