# Fast-fuel composition audit (read-only)

Scope: `/home/cloud/research/pB11_reaction`, with the coordinator contract in
`/home/cloud/research/pB-baldur/baldur-code/docs/exl50u-program/API_CONTRACT.md`.
`AGENTS.md` requires explicit units/model contracts, preservation of the C/C++/
Fortran ABI, and keeping BALDUR state out of the library (`AGENTS.md:3-7`). No
repository files or tests were changed/run.

## Contract boundary

The coordinator contract allows stateless evaluators to receive explicit species,
density, thermal-energy and optional nonthermal-distribution inputs, and requires
stateful trial/commit/discard ownership (`API_CONTRACT.md:15-20`). The library is
the owner of nuclear sources, fast birth spectra, collisions and energy ledgers;
the host owns geometry, spatial transport/injection and acceptance (`API_CONTRACT.md:21-27`).
Fast birth, slowing/thermalization and ash must be entered once, and accepted
state/rollback is host controlled (`API_CONTRACT.md:23-27`).

## Existing fast-fuel target burn

`fusion_c_target_burn_trial(cells, dt_s, edges_J, old_fast_m3,
target_number_m3, target_energy_J_m3, reactivity_m3_s[K_i],
target_energy_reactivity_J_m3_s[M_i], trial_fast_m3, reaction_loss_m3,
out)` is a reaction-only backward-Euler trial (`include/fusion_target_burn.h:15-36`).
The fast population is an arbitrary nonnegative energy histogram; cell energies
are arithmetic edge centers. Each event consumes one fast particle and one
shared target, with no identical-pair factor. `K_i` is m3/s and `M_i` is the
integral sigma*v*E_target in J m3/s; the target debit is
`reaction_loss_i*M_i/K_i`, never an assumed 3kT/2 (`include/fusion_target_burn.h:15-24`).

The returned `trial_fast_m3` and `reaction_loss_m3` are per-bin densities
(m-3), and `fusion_target_burn_v1` carries initial/final fast and target number
and energy, total reactions, removed fast/target energy, and three residuals
(`include/fusion_target_burn.h:7-14`). Inputs are unchanged and there is no
hidden state; products, Q, collisions, fast-fast reactions, ash or deposition
are explicitly outside this operator (`include/fusion_target_burn.h:25-31`).

`fusion_c_beam_target_burn_window_trial` obtains each bin's K/M by calling the
beam window at the center energy, for an explicit-mass monoenergetic projectile
against a stationary isotropic Maxwellian target; it initializes target energy
as 3*n*kT/2 and returns one `fusion_beam_window_v1` diagnostic per bin
(`include/fusion_target_burn.h:37-49`, `src/fusion_target_burn.cpp:77-95`).
This is a finite nuclear window result, not a complete physical burn.

Already tested: analytic one-bin BE root, per-bin particle/fast-energy/target-
energy closure, deterministic repeatability and overdraw rejection; multi-bin
shared-target competition and inert bins; cold/warm pB window composition and
reaction-conditioned target debit (`tests/test_fusion_target_burn.cpp:10-60`).
The validation explicitly says products/Q/collisions/escape remain separate
(`docs/TARGET_BURN.md:3-6`, `docs/TARGET_BURN.md:38-63`).

## Unequal-temperature rate primitives

`fusion_c_thermal_pair_maxwellian_window(channel, ma, mb, Ta_J, Tb_J, out)`
accepts two independent, zero-drift Maxwellians, possibly unequal kT, and
explicit masses (`include/fusion_beam.h:55-65`). `fusion_beam_window_v1` returns
resolved reactivity, projectile/target/relative/CM energy moments, resolved and
unresolved probabilities/speed, quadrature error, energy-identity residual and
`domain_incomplete` (`include/fusion_beam.h:8-20`). It is density-free and adds
no identical-pair factor. The moments are reaction-conditioned integrals, not
3Ta/2 and 3Tb/2 assignments (`include/fusion_beam.h:45-50`, `docs/BEAM_AND_THERMAL_MOMENTS.md:82-106`).

The model variant adds explicit continuation/low-policy inputs and returns
fit/below/above/total records (`include/fusion_rate_model.h:7-45`); it still
does no depletion or product generation (`docs/RATE_MODEL.md:31-64`).
Beam rates support a monoenergetic projectile plus isotropic Maxwellian target;
the unequal-T API supports only the two Maxwellians. These are rate/debit
primitives, not a joint reacting-velocity or product-angle distribution.

Already tested: independent projectile averaging for the unequal-T rate and
both species energy moments, species swap, equal-T CM identity and one-cold-
reactant limit (`tests/test_fusion_beam.cpp:164-200`); model segment sums and
unequal-T species exchange (`tests/test_fusion_rate_model.cpp:389-417`).

## Common-temperature thermal birth and coupled operator

`fusion_c_thermal_birth_grid(channel, kT_J, options, cells, edges_J, birth,
out)` accepts one common positive kT, explicit source/model options, an energy
grid and returns `birth[7*cells]` coefficients (species 0..5 plus neutron 6)
in m3/s. The caller multiplies by `n_a*n_b/(1+delta_ab)` exactly once. The
result carries source/reference rates, both selected-reactant energy moments,
product energy, number/energy residuals, discrepancy/tail diagnostics and
below/above spill number/energy (`include/fusion_thermal_birth.h:16-72`).
It supports all five canonical channels, two zero-drift isotropic Maxwellians at
the SAME kT, and isotropic global CM event rotation. It does not support
unequal-T, beam, pitch/current correlations, automatic thermalization, escape or
spill handling (`include/fusion_thermal_birth.h:34-45`; `docs/THERMAL_BIRTH.md:1-28`).

Tests cover all five channels, product multiplicities, full product energy
including spills, independent rate and both debit references, relative-grid
refinement, finite-CM-tail diagnostics and pB source options
(`tests/test_fusion_thermal_birth.cpp:132-218`, `tests/test_fusion_thermal_birth.cpp:221-283`).

`fusion_c_coupled_thermal_trial` takes dt/options, grid, six thermal densities,
Ue/Ui, ne, six thermal <Z2>, inert-bath descriptors, Coulomb logs, old fast S/T
arrays, external fast birth rates and escape rates; it returns trial thermal
densities, trial S/T arrays and `fusion_coupled_thermal_v1`
(`include/fusion_coupled_thermal.h:61-110`). The result ledger has channel
events; nuclear/external born number and energy; thermal and fast consumed
number/energy; escaped/handed-off number/energy; heat to seven baths; neutron
number/energy; thermal energies and residuals (`include/fusion_source_state.h:17-27`).
The direct and immutable-table variants share the same common-T burn -> birth ->
FP -> heat/handoff split; table mode only replaces coefficient evaluation
(`include/fusion_coupled_thermal.h:111-146`; `src/fusion_coupled_thermal.cpp:84-123`).
The coupled operator has no fast-fuel nuclear reaction path; its external birth
input is already a supplied fast source (`include/fusion_coupled_thermal.h:75-88`).

The coupled DT test verifies one D and one T consumed per event, one alpha and
one explicit neutron born, Q closure against thermal+fast debits, per-species
fast number/energy identities, bath heat and total thermal/fast/neutron energy
closure (`tests/test_fusion_coupled_thermal.cpp:584-760`). This is common-T
source evidence, not fast-target LAB-birth evidence.

## Concrete missing LAB-birth connection

The pieces are present but the composition edge is missing:

1. `fusion_c_reaction_lab_event` accepts one channel-ordered pair of explicit
   momenta, one CM direction and (for pB) one q/cosine/azimuth, and returns one
   deterministic two- or three-product LAB event plus parent/boost ledgers
   (`include/fusion_reaction_event.h:17-50`). It deliberately selects no
   reacting-pair probability, angular distribution or source weight
   (`docs/REACTION_EVENT.md:1-7`, `docs/REACTION_EVENT.md:46-61`).
2. `fusion_c_map_birth_packets` only projects caller-supplied product energy
   packets/rates onto one energy grid and reports explicit below/above spill
   (`include/fusion_products.h:16-29`; `docs/PRODUCT_KINEMATICS_AND_MAPPING.md:33-52`).
   It does not create packets, assign product species or provide a fast-target
   conditional distribution.
3. Target burn returns exactly the accepted event amount per fast bin and the
   two reactant energy debits, but no conditional target velocity, CM velocity,
   outgoing-angle/q distribution or product packet stream. The moments API only
   supplies scalar rate and energy moments; the common-T birth API explicitly
   excludes beam/unequal-T angular correlations.

Minimal next connection: add one stateless fast-fuel birth evaluator (or an
equivalent prepared source provider) that, for each target-burn fast bin,
integrates the reaction-conditioned Maxwellian target velocities and validated
outgoing event variables, calls the LAB event primitive, and emits
species-specific LAB energy packets/grid coefficients plus explicit spill and
neutron ledgers. It must consume the accepted `reaction_loss_m3` event amount
exactly once, and enforce the existing budget
`product kinetic = Q*events + removed fast energy + removed target energy`
including neutron/escape policy. Then pass its charged packets into the existing
fast S/T source path and place `nuclear_born_*`, `fast_consumed_*`, and residuals
in the same trial/commit ledger. Do not infer that distribution from scalar
moments or insert products directly into heat. This is the smallest bridge
consistent with the target-burn ownership statement (`include/fusion_target_burn.h:25-27`),
the LAB-event limitation (`docs/REACTION_EVENT.md:80-83`), and the host/library
source ownership contract (`API_CONTRACT.md:21-27`).

The coordinator already records this exact remaining scope: unequal-T/beam
births and fast-fuel composition remain open (`SOURCE_EVALUATION_NEXT.md:3-7`,
`SOURCE_EVALUATION_NEXT.md:76-80`; `M3_BIRTH_TABLE_VALIDATION.md:71-74`).
