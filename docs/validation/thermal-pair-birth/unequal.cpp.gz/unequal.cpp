#include "fusion_thermal_birth.h"
#include <vector>
#include <cstdio>
#include <chrono>
#include <cstdlib>
int main(int argc,char**argv){constexpr double k=1.602176634e-16,m=1.602176634e-13;int n=100;
std::vector<double> e(n+1),b(7*n);for(int j=0;j<=n;++j)e[j]=25*m*j/n;
fusion_thermal_birth_options_v1 o{2.5*m,40,.09184*m,.001*m,.76,0,.051,1,1,0,0,13,0,16,12,8,8};
fusion_thermal_birth_v1 r{};auto t=std::chrono::steady_clock::now();int s=fusion_c_thermal_pair_birth_grid(3,20*k,40*k,8,&o,n,e.data(),b.data(),&r);
std::fprintf(stderr,"status=%d seconds=%.9g rate=%.17g number_residual=%.17g energy_residual=%.17g\n",s,std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count(),r.reactivity_m3_s,r.number_residual_m3_s,r.energy_residual_J_m3_s);
std::fprintf(stderr,"relative_rate=%.12g debit=%.12g\n",r.relative_rate_discrepancy,r.relative_reactant_energy_discrepancy);std::fwrite(&r,sizeof r,1,stdout);std::fwrite(b.data(),sizeof(double),b.size(),stdout);return s;}
