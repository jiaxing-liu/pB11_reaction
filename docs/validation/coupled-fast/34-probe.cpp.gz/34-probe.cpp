#define main inherited_test_main
#include "/home/cloud/research/pB11_reaction/tests/test_fusion_coupled_thermal.cpp"
#undef main
#include "fusion_coupled_fast.h"
#include <cstdio>
int main(){Inputs in;int n=in.grid.cells();int idx=FUSION_DEUTERON*n+nearest_cell(in.grid,100*kKeVJ);in.old_s[idx]=1e17;in.old_t[idx]=2e17;fusion_fast_target_options_v1 fast{{0,0,0,1,0},16,40};Trial t=make_trial(in);int st=fusion_c_coupled_fast_trial(1e-4,&in.options,&fast,n,in.grid.edges.data(),in.thermal_number.data(),in.electron_energy_J_m3,in.ion_energy_J_m3,in.electron_density_m3,in.thermal_charge_squared.data(),in.inert_count,in.inert.data(),in.coulomb_logs.data(),in.old_s.data(),in.old_t.data(),in.external_birth.data(),in.escape.data(),t.thermal_number.data(),t.s.data(),t.t.data(),&t.result);printf("status%d DTevents%.17g fastD%.17g thermalT%.17g neutron%.17g totalEnergyResidual%.17g\n",st,t.result.ledger.events_m3[3],t.result.ledger.fast_consumed_number_m3[1],t.result.ledger.thermal_consumed_number_m3[2],t.result.ledger.neutron_number_m3,t.result.energy_residual_J_m3);return st;}
