#include <fusion_coupled_fast.h>
#include <stdio.h>
int main(void){int status=fusion_c_coupled_fast_trial(1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);if(status!=PB11_STATUS_NULL_OUTPUT)return 1;puts("Installed C11 coupled-fast ABI/null-output check passed");return 0;}
