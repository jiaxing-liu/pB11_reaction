#define main inherited_test_main
#include "/home/cloud/research/pB11_reaction/tests/test_fusion_coupled_thermal.cpp"
#undef main
#include <cstdio>
int main(int argc,char**argv){if(argc!=2)return 2;FILE*f=std::fopen(argv[1],"wb");if(!f)return 2;for(int mode=0;mode<2;++mode){Inputs in;in.options=make_options(Channels{{0,0,0,mode,0}});int idx=FUSION_HELIUM4*in.grid.cells()+nearest_cell(in.grid,3.5*kMeVJ);in.old_s[idx]=1e12;Trial t=make_trial(in);int st=call_trial(in,1e-4,t);if(st)return st;std::fwrite(&t.result,sizeof(t.result),1,f);std::fwrite(t.thermal_number.data(),sizeof(double),6,f);std::fwrite(t.s.data(),sizeof(double),t.s.size(),f);std::fwrite(t.t.data(),sizeof(double),t.t.size(),f);}std::fclose(f);return 0;}
