#include "fusion_target_network.h"
#include <cstdio>
#include <cmath>
#include <random>
#include <vector>
int main(){std::mt19937_64 gen(51);std::uniform_real_distribution<double> u(-3,3);int failed=0;double err=0;int maxit=0;
for(int run=0;run<500;++run){int nf=7,nt=3;std::vector<double> fin(nf),bf(nt),old(nf),B(nt),U(nt,1e200),en(nf,1),n(nf),b(nt),eu(nt),r;std::vector<fusion_target_network_edge_v1> e;
for(auto&x:fin)x=pow(10.,u(gen));for(auto&x:bf)x=pow(10.,u(gen));old=fin;B=bf;
for(int i=0;i<nf;++i)for(int j=0;j<nt;++j){double k=pow(10.,u(gen));e.push_back({i,j,k,k});old[i]+=k*fin[i]*bf[j];B[j]+=k*fin[i]*bf[j];}r.resize(e.size());fusion_target_network_v1 out{};
int st=fusion_c_target_network_trial(nf,nt,e.size(),1,en.data(),old.data(),B.data(),U.data(),e.data(),n.data(),b.data(),eu.data(),r.data(),&out);
if(st){printf("FAIL case%d status%d\n",run,st);++failed;continue;}maxit=std::max(maxit,out.iterations);for(int i=0;i<nf;++i)err=std::max(err,std::abs(n[i]/fin[i]-1));for(int j=0;j<nt;++j)err=std::max(err,std::abs(b[j]/bf[j]-1));
}printf("cases500 failures%d max_solution_relative%.17g max_iterations%d\n",failed,err,maxit);return failed?1:0;}
