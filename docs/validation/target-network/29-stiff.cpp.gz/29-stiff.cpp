#include <initializer_list>
#include "fusion_target_network.h"
#include <cstdio>
#include <cmath>
int main(){int failures=0;for(double k:{1e-200,1.,1e20,1e100,1e200}){double E=1,F=1,B=1,U=10,n,b,u,r;fusion_target_network_edge_v1 edge{0,0,k,k};fusion_target_network_v1 out{};int st=fusion_c_target_network_trial(1,1,1,1,&E,&F,&B,&U,&edge,&n,&b,&u,&r,&out);double exact=2/(1+sqrt(1+4*k));printf("K%.1e st%d n%.17g b%.17g expected%.17g rel%.3g iterations%d\n",k,st,n,b,exact,st?0:fabs(b/exact-1),out.iterations);if(st||fabs(b/exact-1)>1e-8)failures++;}return failures?1:0;}
