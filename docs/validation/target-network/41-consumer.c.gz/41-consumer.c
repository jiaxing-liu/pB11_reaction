#include <fusion_target_network.h>
#include <math.h>
#include <stdio.h>
int main(void){double E=1,F=1,B=1,U=10,n,b,u,r;fusion_target_network_edge_v1 e={0,0,1,1};fusion_target_network_v1 result={0};int st=fusion_c_target_network_trial(1,1,1,1,&E,&F,&B,&U,&e,&n,&b,&u,&r,&result);if(st||fabs(b-(sqrt(5)-1)/2)>1e-12)return 1;puts("Installed C11 target-network consumer passed");return 0;}
