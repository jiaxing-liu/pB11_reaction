#include "fusion_target_network.h"
#include <cstdio>
#include <cmath>
#include <initializer_list>
int main(){double previous=0;for(int steps:{40,80,160,320}){double F=2,B[2]={1,1},U[2]={10,10},E=1,n,b[2],u[2],loss[2];fusion_target_network_edge_v1 edges[2]={{0,0,1,1},{0,1,1,1}};
for(int i=0;i<steps;++i){fusion_target_network_v1 out{};int st=fusion_c_target_network_trial(1,2,2,1./steps,&E,&F,B,U,edges,&n,b,u,loss,&out);if(st)return st;F=n;for(int j=0;j<2;++j){B[j]=b[j];U[j]=u[j];}}
double error=std::abs(B[0]-1./3);printf("steps%d finalB%.17g error%.17g ratio%.9g\n",steps,B[0],error,previous/error);if(previous&&!(previous/error>1.8&&previous/error<2.1))return 1;previous=error;}return 0;}
