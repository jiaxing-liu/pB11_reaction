#include "fusion_beam_birth.h"

#include <math.h>
#include <stdio.h>

int main(void)
{
    enum { cells = 8, species = 7 };
    const double kev = 1.602176634e-16;
    const double mev = 1.602176634e-13;
    double edges[cells + 1];
    double birth[species * cells];
    fusion_beam_birth_options_v1 options = {0};
    fusion_beam_birth_v1 result = {0};

    for (int i = 0; i <= cells; ++i)
        edges[i] = 20.0 * mev * (double)i / (double)cells;

    options.relative_max_J = 200.0 * kev;
    options.angular_max_exponent = 40.0;
    options.ground_state_q_J = 91.84 * kev;
    options.cutoff_J = 0.001 * mev;
    options.l1_fraction = 0.76;
    options.relative_phase = 0.0;
    options.narrow_peak_fraction = 0.051;
    options.continuum_peak_scale = 1.0;
    options.continuation = 1;
    options.pb_low = 0;
    options.remainder_policy = FUSION_PB_REMAINDER_ENTRANCE_PROXY;
    options.broad_mode = 13;
    options.fsci_policy = 0;
    options.relative_order = 4;
    options.angular_order = 4;
    options.nq = 4;
    options.ncos = 4;

    const int status = fusion_c_beam_birth_grid(
        3, 0, 100.0 * kev, 0.0, &options, cells, edges, birth, &result);
    if (status != PB11_STATUS_OK ||
        !(result.spectrum.reactivity_m3_s > 0.0) ||
        !(result.spectrum.reference_reactivity_m3_s > 0.0) ||
        !isfinite(result.spectrum.reactivity_m3_s) ||
        !(result.relative_retained_probability > 0.0) ||
        !(result.retained_pair_probability > 0.0)) {
        fprintf(stderr, "installed C beam birth consumer failed: status=%d rate=%g ref=%g\n",
                status, result.spectrum.reactivity_m3_s,
                result.spectrum.reference_reactivity_m3_s);
        return 1;
    }

    int nonzero_bins = 0;
    for (int i = 0; i < species * cells; ++i)
        if (birth[i] > 0.0) ++nonzero_bins;
    if (nonzero_bins == 0) {
        fprintf(stderr, "installed C beam birth consumer produced no bins\n");
        return 2;
    }

    printf("installed C beam birth consumer passed: rate=%.17g nonzero_bins=%d\n",
           result.spectrum.reactivity_m3_s, nonzero_bins);
    return 0;
}
