program installed_beam_birth_consumer
  use, intrinsic :: iso_c_binding, only : c_double, c_int
  use fusion_beam_birth_fortran
  implicit none

  real(c_double), parameter :: kev = 1.602176634e-16_c_double
  real(c_double), parameter :: mev = 1.602176634e-13_c_double
  integer(c_int), parameter :: cells = 8_c_int
  real(c_double), target :: edges(cells + 1)
  real(c_double), target :: birth(cells, FUSION_BEAM_BIRTH_SPECIES)
  type(fusion_beam_birth_options_v1), target :: options
  type(fusion_beam_birth_v1), target :: result
  integer(c_int) :: status
  integer :: i

  call make_options(options)
  do i = 1, cells + 1
     edges(i) = 20.0_c_double * mev * real(i - 1, c_double) / &
          real(cells, c_double)
  end do
  call fusion_beam_birth_grid(FUSION_DT_ALPHAN, 0_c_int, &
       100.0_c_double * kev, 0.0_c_double, options, edges, birth, result, status)

  if (status /= PB11_STATUS_OK .or. &
       result%spectrum%reactivity_m3_s <= 0.0_c_double .or. &
       result%spectrum%reference_reactivity_m3_s <= 0.0_c_double .or. &
       result%relative_retained_probability <= 0.0_c_double .or. &
       result%retained_pair_probability <= 0.0_c_double .or. &
       maxval(birth) <= 0.0_c_double) then
     write(*, '(A,I0,A,ES24.16)') &
          'installed Fortran beam birth consumer failed: status=', status, &
          ' rate=', result%spectrum%reactivity_m3_s
     error stop 1
  end if

  write(*, '(A,ES24.16)') &
       'installed Fortran beam birth consumer passed: rate=', &
       result%spectrum%reactivity_m3_s

contains

  subroutine make_options(o)
    type(fusion_beam_birth_options_v1), intent(out) :: o

    o%relative_max_J = 200.0_c_double * kev
    o%angular_max_exponent = 40.0_c_double
    o%ground_state_q_J = 91.84_c_double * kev
    o%cutoff_J = 0.001_c_double * mev
    o%l1_fraction = 0.76_c_double
    o%relative_phase = 0.0_c_double
    o%narrow_peak_fraction = 0.051_c_double
    o%continuum_peak_scale = 1.0_c_double
    o%continuation = FUSION_ENDPOINT_S
    o%pb_low = FUSION_PB_LOW_TB
    o%remainder_policy = FUSION_PB_REMAINDER_ENTRANCE_PROXY
    o%broad_mode = 13_c_int
    o%fsci_policy = 0_c_int
    o%relative_order = 4_c_int
    o%angular_order = 4_c_int
    o%nq = 4_c_int
    o%ncos = 4_c_int
  end subroutine make_options

end program installed_beam_birth_consumer
