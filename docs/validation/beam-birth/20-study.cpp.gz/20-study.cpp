#include <fusion_beam_birth.h>
#include <cstdio>
#include <vector>
#include <cmath>
#include <chrono>
int main(){constexpr double k=1.602176634e-16,m=1.602176634e-13;int n=128;std::vector<double> e(n+1),g(7*n),old(7*n);for(int j=0;j<=n;++j)e[j]=25*m*j/n;
std::puts("channel,projectile_keV,target_keV,angle_order,seconds,rate_error,debit_error,relative_probability,retained_probability,omitted_angle_probability,number_L1_previous,energy_L1_previous");
for(int ch:{3,0}){fusion_beam_birth_v1 prior{};for(int order:{4,8,16}){
fusion_beam_birth_options_v1 o{2.5*m,40,.09184*m,.001*m,.76,0,.051,1,1,0,0,13,0,16,order,8,8};fusion_beam_birth_v1 r{};double ep=ch?50:675,tt=ch?10:30;
auto t=std::chrono::steady_clock::now();int status=fusion_c_beam_birth_grid(ch,0,ep*k,tt*k,&o,n,e.data(),g.data(),&r);if(status){std::fprintf(stderr,"ch%d order%d status%d\n",ch,order,status);return status;}
long double dn=0,de=0,N=0,E=0;for(int id=0;id<7;++id){auto&a=r.spectrum;auto&b=prior.spectrum;dn+=std::abs(a.below_number_m3_s[id]-b.below_number_m3_s[id])+std::abs(a.above_number_m3_s[id]-b.above_number_m3_s[id]);de+=std::abs(a.below_energy_J_m3_s[id]-b.below_energy_J_m3_s[id])+std::abs(a.above_energy_J_m3_s[id]-b.above_energy_J_m3_s[id]);N+=a.below_number_m3_s[id]+a.above_number_m3_s[id];E+=a.below_energy_J_m3_s[id]+a.above_energy_J_m3_s[id];for(int j=0;j<n;++j){int i=id*n+j;long double c=(e[j]+e[j+1])/2;dn+=std::abs(g[i]-old[i]);de+=c*std::abs(g[i]-old[i]);N+=g[i];E+=c*g[i];}}
std::printf("%d,%.9g,%.9g,%d,%.9g,%.9g,%.9g,%.17g,%.17g,%.9g,%.9Lg,%.9Lg\n",ch,ep,tt,order,std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count(),r.spectrum.relative_rate_discrepancy,r.spectrum.relative_reactant_energy_discrepancy,r.relative_retained_probability,r.retained_pair_probability,r.angular_omitted_pair_probability,order==4?0:dn/N,order==4?0:de/E);std::fflush(stdout);old=g;prior=r;
}}
}
